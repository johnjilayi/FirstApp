

function Activity1() {
    const name = "jonathan Njilayi";
    return (
        <h>Hello, {name}</h>
    )
}


export default Activity1;