import React from "react";


class Activity2 extends React.Component {
    render() {
        return <h>{new Date().toDateString()}</h>
    }
}

export default Activity2;